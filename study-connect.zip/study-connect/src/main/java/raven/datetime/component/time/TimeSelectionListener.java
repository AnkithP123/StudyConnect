package raven.datetime.component.time;

public interface TimeSelectionListener {

    void timeSelected(TimeEvent timeEvent);
}
