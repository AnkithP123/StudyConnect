package raven.datetime.component.date;

public interface DateSelectionListener {

    void dateSelected(DateEvent dateEvent);
}
