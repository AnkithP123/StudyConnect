package prog.hackathon;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class FindTime2 {
    final int MIN_LIMIT = 10;
    public StudyGroup[] findTime(Users users) {

        ArrayList<Users.User> list = users.getUsers();
        Calendar lowestDate = Calendar.getInstance();
        Calendar highestDate = Calendar.getInstance();
        lowestDate.set(Calendar.HOUR, Integer.MAX_VALUE);
        highestDate.set(Calendar.HOUR, 0);
        lowestDate.set(Calendar.SECOND, 0);
        highestDate.set(Calendar.SECOND, 0);

        // find min and max times
        for(Users.User user : list) {
            ArrayList<Schedule.TimeSlot> timeSlots = user.schedule.timeSlots;
            for(Schedule.TimeSlot timeSlot : timeSlots) {
                if(timeSlot.startTimeSlot.getTime().getTime() < (lowestDate.getTime().getTime())) {
                    lowestDate = timeSlot.startTimeSlot;
                }
                if (timeSlot.endTimeSlot.getTime().getTime() > (highestDate.getTime().getTime())) {
                    highestDate = timeSlot.endTimeSlot;
                }
            }
        }

        return null;
    }

    public static void main(String[] args) {
        FindTime2 findTime = new FindTime2();
        Users users = new Users();
        Date date = new Date();
        date.setHours(10);
        date.setMinutes(0);
        date = (new Calendar.Builder().setInstant(date).build()).getTime();
        Date date2 = new Date();
        date2.setHours(12);
        date2.setMinutes(0);
        date2 = (new Calendar.Builder().setInstant(date2).build()).getTime();
        Date date3 = new Date();
        date3.setHours(11);
        date3.setMinutes(0);
        date3 = (new Calendar.Builder().setInstant(date3).build()).getTime();
        Date date4 = new Date();
        date4.setHours(16);
        date4.setMinutes(0);
        date4 = (new Calendar.Builder().setInstant(date4).build()).getTime();
        Schedule schedule = new Schedule();
        schedule.addTimeSlot(date, date2);
        Schedule schedule2 = new Schedule();
        schedule2.addTimeSlot(date3, date4);
        users.addUser(new Account("Hello", "hi", 1), null);
        users.addUser(new Account("Hello", "hi", 1), null);
        users.getUsers().get(0).schedule = schedule;
        users.getUsers().get(1).schedule = schedule2;
        Date date5 = new Date();
        date5.setHours(10);
        date5.setMinutes(55);
        date5 = (new Calendar.Builder().setInstant(date5).build()).getTime();
        Date date6 = new Date();
        date6.setHours(11);
        date6.setMinutes(35);
        date6 = (new Calendar.Builder().setInstant(date6).build()).getTime();
        Schedule schedule3 = new Schedule();
        schedule.addTimeSlot(date5, date6);
        users.addUser(new Account("Hello", "hi", 1), null);
        users.getUsers().get(2).schedule = schedule3;
        //System.out.println(date5.getTime() - (30 * 60 * 1000));
        findTime.findTime(users);
    }

    private static Calendar GMT( Calendar c ){
        Date date = c.getTime();
        TimeZone tz = TimeZone.getDefault();
        Date ret = new Date( date.getTime() - tz.getRawOffset() );

        // if we are now in DST, back off by the delta.  Note that we are checking the GMT date, this is the KEY.
        if ( tz.inDaylightTime( ret )){
            Date dstDate = new Date( ret.getTime() - tz.getDSTSavings() );

            // check to make sure we have not crossed back into standard time
            // this happens when we are on the cusp of DST (7pm the day before the change for PDT)
            if ( tz.inDaylightTime( dstDate )){
                ret = dstDate;
            }
        }
        return new Calendar.Builder().setInstant(ret).build();
    }

    class StudyGroup {
        private Calendar date;
        private String subject;
        private Users[] participants;
    }
}
