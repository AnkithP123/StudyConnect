package prog.hackathon;

import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.extras.FlatAnimatedLafChange;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import com.formdev.flatlaf.util.UIScale;
import net.miginfocom.swing.MigLayout;
import raven.datetime.component.date.DateEvent;
import raven.datetime.component.date.DatePicker;
import raven.datetime.component.date.DateSelectionListener;
import raven.datetime.component.time.TimeEvent;
import raven.datetime.component.time.TimePicker;
import raven.datetime.component.time.TimeSelectionListener;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class TestDate extends JFrame {

    private DatePicker datePicker;
    private TimePicker start;
    private TimePicker end;

    public TestDate(Schedule s, JTextArea schedule) {
        setSize(UIScale.scale(new Dimension(800, 600)));
        setLocationRelativeTo(null);
        setLayout(new MigLayout("wrap"));
        datePicker = new DatePicker();
        datePicker.setDateSelectionMode(DatePicker.DateSelectionMode.BETWEEN_DATE_SELECTED);
        datePicker.addDateSelectionListener(new DateSelectionListener() {
            @Override
            public void dateSelected(DateEvent dateEvent) {

                DateTimeFormatter df = DateTimeFormatter.ofPattern("MM-dd-yyyy");
                if (datePicker.getDateSelectionMode() == DatePicker.DateSelectionMode.SINGLE_DATE_SELECTED) {
                    LocalDate date = datePicker.getSelectedDate();
                    if (date != null) {
                        System.out.println("date change " + df.format(datePicker.getSelectedDate()));
                    } else {
                        System.out.println("date change to null");
                    }
                } else {
                    LocalDate dates[] = datePicker.getSelectedDateRange();
                    if (dates != null) {
                        System.out.println("date change " + df.format(dates[0]) + " to " + df.format(dates[1]));
                    } else {
                        System.out.println("date change to null");
                    }
                }
                if (start.getSelectedTime() != null && end.getSelectedTime() != null && datePicker.getSelectedDateRange() != null) {
                    Schedule.TimeSlot ts = s.new TimeSlot(Date.from(getStartDateAndTime().toInstant()), Date.from(getEndDateAndTime().toInstant()));
                    s.removeTimeSlot(s.timeSlots.size() - 1);    
                    s.addTimeSlot(getStartDateAndTime().getTime(), getEndDateAndTime().getTime());
                    // change the last line of the schedule to correspond to the new time
                    schedule.setText(schedule.getText().substring(0, schedule.getText().lastIndexOf("\n")) + "\n" + ts.startTimeSlot.getTime().toString() + " to " + ts.endTimeSlot.getTime().toString());
                }
            }
        });

        // datePicker.setDateSelectionAble((date) -> !date.isAfter(LocalDate.now()));
        datePicker.now();
        JFormattedTextField editor = new JFormattedTextField();
        datePicker.setEditor(editor);
        JPanel pan = new JPanel();
        add(editor, "width 250");
        JPanel panel = new JPanel(new MigLayout("wrap"));
        panel.setBorder(new TitledBorder("Start and End"));
        start = new TimePicker();
        panel.add(start);
        pan.add(panel);
        JPanel panel2 = new JPanel(new MigLayout("wrap"));
        panel2.setBorder(new TitledBorder("End Time"));
        end = new TimePicker();
        panel2.add(end);
        pan.add(panel2);
        start.addTimeSelectionListener(new TimeSelectionListener() {
            @Override
            public void timeSelected(TimeEvent timeEvent) {
                if (start.getSelectedTime() != null && end.getSelectedTime() != null && datePicker.getSelectedDateRange() != null) {
                    Schedule.TimeSlot ts = s.new TimeSlot(Date.from(getStartDateAndTime().toInstant()), Date.from(getEndDateAndTime().toInstant()));
                    s.removeTimeSlot(s.timeSlots.size() - 1);    
                    s.addTimeSlot(getStartDateAndTime().getTime(), getEndDateAndTime().getTime());
                    // change the last line of the schedule to correspond to the new time
                    schedule.setText(schedule.getText().substring(0, schedule.getText().lastIndexOf("\n")) + "\n" + ts.startTimeSlot.getTime().toString() + " to " + ts.endTimeSlot.getTime().toString());
                }
            }
        });
        end.addTimeSelectionListener(new TimeSelectionListener() {
            
            @Override
            public void timeSelected(TimeEvent timeEvent) {
                if (start.getSelectedTime() != null && end.getSelectedTime() != null && datePicker.getSelectedDateRange() != null) {
                    Schedule.TimeSlot ts = s.new TimeSlot(Date.from(getStartDateAndTime().toInstant()), Date.from(getEndDateAndTime().toInstant()));
                    s.removeTimeSlot(s.timeSlots.size() - 1);    
                    s.addTimeSlot(getStartDateAndTime().getTime(), getEndDateAndTime().getTime());
                    // change the last line of the schedule to correspond to the new time
                    schedule.setText(schedule.getText().substring(0, schedule.getText().lastIndexOf("\n")) + "\n" + ts.startTimeSlot.getTime().toString() + " to " + ts.endTimeSlot.getTime().toString());
                }
            }
        });
        add(pan);

    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menuFile = new JMenu("File");
        JMenu menuThemes = new JMenu("Themes");
        JMenuItem menuExit = new JMenuItem("Exit");
        ButtonGroup group = new ButtonGroup();
        JCheckBoxMenuItem menuMacDark = new JCheckBoxMenuItem("Mac Dark");
        JCheckBoxMenuItem menuMacLight = new JCheckBoxMenuItem("Mac Light");
        group.add(menuMacDark);
        group.add(menuMacLight);

        menuMacDark.setSelected(true);

        menuExit.addActionListener(e -> System.exit(0));

        menuFile.add(menuExit);
        menuBar.add(menuFile);
        menuBar.add(menuThemes);
        setJMenuBar(menuBar);
    }

    public Calendar getStartDateAndTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, start.getSelectedTime().getHour());
        calendar.set(Calendar.MINUTE, start.getSelectedTime().getMinute());
        calendar.set(Calendar.DAY_OF_MONTH, datePicker.getSelectedDate().getDayOfMonth());
        calendar.set(Calendar.MONTH, datePicker.getSelectedDate().getMonthValue());
        calendar.set(Calendar.YEAR, datePicker.getSelectedDate().getYear());
        return calendar;
    }

    public Calendar getEndDateAndTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, end.getSelectedTime().getHour());
        calendar.set(Calendar.MINUTE, end.getSelectedTime().getMinute());
        calendar.set(Calendar.DAY_OF_MONTH, datePicker.getSelectedDate().getDayOfMonth());
        calendar.set(Calendar.MONTH, datePicker.getSelectedDate().getMonthValue());
        calendar.set(Calendar.YEAR, datePicker.getSelectedDate().getYear());
        return calendar;
    }

    private void createDateOption() {
        JPanel panel = new JPanel(new MigLayout("wrap"));
        panel.setBorder(new TitledBorder("Option"));
        JCheckBox chBtw = new JCheckBox("Use Date between");
        chBtw.addActionListener(e -> {
            if (chBtw.isSelected()) {
                datePicker.setDateSelectionMode(DatePicker.DateSelectionMode.BETWEEN_DATE_SELECTED);
            } else {
                datePicker.setDateSelectionMode(DatePicker.DateSelectionMode.SINGLE_DATE_SELECTED);
            }
        });
        JCheckBox chDateOpt = new JCheckBox("Use Panel Option");
        chDateOpt.addActionListener(e -> datePicker.setUsePanelOption(chDateOpt.isSelected()));

        JCheckBox chClose = new JCheckBox("Close after selected");
        chClose.addActionListener(e -> datePicker.setCloseAfterSelected(chClose.isSelected()));

        panel.add(chBtw);
        panel.add(chDateOpt);
        panel.add(chClose);
        add(panel);
    }



    public static void main(String[] args) {
        FlatLaf.registerCustomDefaultsSource("themes");
        UIManager.put("defaultFont", new Font(new JTextArea().getFont().getFamily(), Font.PLAIN, 13));
        FlatMacDarkLaf.setup();
        EventQueue.invokeLater(() -> new TestDate(null, null).setVisible(true));
    }
}
