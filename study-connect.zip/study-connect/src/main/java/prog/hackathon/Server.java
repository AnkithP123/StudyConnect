package prog.hackathon;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.apps.meet.v2.CreateSpaceRequest;
import com.google.apps.meet.v2.Space;
import com.google.apps.meet.v2.SpacesServiceClient;
import com.google.apps.meet.v2.SpacesServiceSettings;
import com.google.auth.Credentials;
import com.theokanning.openai.assistants.Assistant;
import com.theokanning.openai.assistants.AssistantRequest;
import com.theokanning.openai.completion.chat.ChatCompletionRequest;
import com.theokanning.openai.completion.chat.ChatMessage;
import com.theokanning.openai.completion.chat.ChatMessageRole;
import com.theokanning.openai.messages.Message;
import com.theokanning.openai.messages.MessageRequest;
import com.theokanning.openai.runs.RunCreateRequest;
import com.theokanning.openai.service.OpenAiService;
import com.theokanning.openai.threads.ThreadRequest;
import com.theokanning.openai.threads.Thread;

import prog.hackathon.Packet.PacketEnum;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.Duration;
import java.io.InputStreamReader;

public class Server {

    ArrayList<Account> accounts = new ArrayList<>();
    ServerSocket serverSocket;
    Users users = new Users();

    public Server() {
        // load accounts from userData.json file
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Account[] loadedAccounts = objectMapper.readValue(new File("userData.json"), Account[].class);
            for (Account account : loadedAccounts) {
                accounts.add(account);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    public void openServer() {
        try {
            serverSocket = new ServerSocket(17047, 1000, InetAddress.getLocalHost());
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(serverSocket.getInetAddress());
        
        while (true) {
            try {
                final Socket sock = serverSocket.accept();
                java.lang.Thread t = new java.lang.Thread() {
                    public void run() {
                        while (true) {
                            try {
                                BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                                String encodedPacket = in.readLine();
                                Packet packet = receivePacket(encodedPacket, sock);
                                if (packet == null) {
                                    continue;
                                }
                                byte[] data = packet.serialize();
                                Base64.Encoder encoder = Base64.getEncoder();
                                String encoded = encoder.encodeToString(data);
                                PrintWriter out = new PrintWriter(sock.getOutputStream(), true);
                                out.println(encoded);
                                out.flush();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                };
                t.start();
               
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public Packet receivePacket(String encodedPacket, Socket socket) {
        if (encodedPacket == null) {
            return new Packet(PacketEnum.ERROR, "Invalid packet");
        }
        byte[] data = Base64.getDecoder().decode(encodedPacket);
        Packet packet = Packet.deserialize(data);
        switch (packet.type) {
            case LOGIN:
                return login((String) packet.data[0], (String) packet.data[1], socket);
            case DECLARE_INFO:
                return declareInfo((String) packet.data[0], (Schedule) packet.data[1], socket);
            case SIGN_UP:
                return registerAccount((String) packet.data[0], (String) packet.data[1], (int) packet.data[2]);
        }
        return null;
    }

    private Packet declareInfo(String string, Schedule schedule, Socket sock) {
        String token = "api key redacted";
        OpenAiService service = new OpenAiService(token, Duration.ofSeconds(100L));
        final List<ChatMessage> messages = new ArrayList<>();
        final ChatMessage systemMessage = new ChatMessage(ChatMessageRole.SYSTEM.value(), "Determine the subject this person is studying based on their message. Respond with ONLY the subject, and nothing else. You will receive your choices after the original message");
        messages.add(systemMessage);
        messages.add(new ChatMessage(ChatMessageRole.USER.value(), string));
        File folder = new File("Subjects");
        String subject = "none";
        while (folder.listFiles().length != 0 || folder.listFiles() == null) {
            File[] files = folder.listFiles();
            String s = "";
            for (File file : files) {
                s += file.getName() + ", ";
            }
            System.out.println("Searching: " + s);
            ChatMessage subjects = new ChatMessage(ChatMessageRole.USER.value(), "Your next message must only be one of these, case-sensitive and exact, with nothing else whatsoever, even more specific. If the option you want is not listed here, pick the closest one. Your options are: " + s);
            messages.add(subjects);
            ChatCompletionRequest chatCompletionRequest = ChatCompletionRequest
                    .builder()
                    .model("gpt-3.5-turbo")
                    .messages(messages)
                    .n(1)
                    .maxTokens(50)
                    .logitBias(new HashMap<>())
                    .build();
            ChatMessage msg = service.createChatCompletion(chatCompletionRequest).getChoices().get(0).getMessage();
            messages.add(msg);
            String response = msg.getContent();
            subject = response;
            System.out.println(response);
            folder = new File(folder, response);
            if (folder.listFiles() == null) {
                subject = folder.getName();
                break;
            }
        }

        users.getUser(sock).subject = subject;
        users.getUser(sock).schedule = schedule;
        

        Packet give = new Packet(PacketEnum.RESPONSE, subject);

        byte[] data = give.serialize();
        Base64.Encoder encoder = Base64.getEncoder();
        String encoded = encoder.encodeToString(data);
        PrintWriter out = null;
        try {
            out = new PrintWriter(sock.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        out.println(encoded);
        out.flush();

        Users newUsers = new Users();
        for (Users.User user : users.getUsers()) {
            if (user.subject != null) {
                newUsers.addUser(user.account, user.socket);
                newUsers.getUser(user.account).subject = user.subject;
                newUsers.getUser(user.account).schedule = user.schedule;
            }
        }

        FindTime timeFinder = new FindTime();
        

        ArrayList<FindTime.StudyGroup> groups = timeFinder.fetchGroups(newUsers);
        System.out.println(groups);
        for (FindTime.StudyGroup group : groups) {
            try {
                Credentials credentials = MeetQuickstart.getCredentials();
                SpacesServiceSettings settings = SpacesServiceSettings.newBuilder()
                    .setCredentialsProvider(FixedCredentialsProvider.create(credentials))
                    .build();
    
                try (SpacesServiceClient spacesServiceClient = SpacesServiceClient.create(settings)) {
                CreateSpaceRequest request = CreateSpaceRequest.newBuilder()
                    .setSpace(Space.newBuilder().build())
                    .build();
                Space response = spacesServiceClient.createSpace(request);
                System.out.printf("Space created: %s\n", response.getMeetingUri());
                for (Users.User user : group.participants) {
                    System.out.println(user.account);
                    String link = response.getMeetingUri();
                    Packet linkPacket = new Packet(PacketEnum.LINK, "Group found for " + group.subject + ": " + link  + " at " + group.date.getTime() + " with " + group.participants.length + " users");
                    byte[] linkData = linkPacket.serialize();
                    Base64.Encoder linkEncoder = Base64.getEncoder();
                    String linkEncoded = linkEncoder.encodeToString(linkData);
                    PrintWriter linkOut = new PrintWriter(user.socket.getOutputStream(), true);
                    System.out.println();
                    linkOut.println(linkEncoded);
                    linkOut.flush();
                }
                
                
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
                return new Packet(PacketEnum.ERROR, "Error with link");
            }
        }
        return null;

    }

    private Packet registerAccount(String username, String password, int grade) {
        Account account = new Account(username, password, grade);
        // make sure account doesn't already exist
        for (Account acc : accounts) {
            if (acc.getUsername().equals(username)) {
                return new Packet(PacketEnum.ERROR, "Account already exists");
            }
        }
        accounts.add(account);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            objectMapper.writeValue(new File("userData.json"), accounts);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new Packet(PacketEnum.SUCCESS, "Account created successfully");
    }

    private Packet login(String username, String password, Socket sock) {
        for (Account account : accounts) {
            if (account.getUsername().equals(username) && account.getPassword().equals(password)) {
                if (users.getUser(account) == null)
                    users.addUser(account, sock);
                return new Packet(PacketEnum.SUCCESS, "Login successful");
            }
        }
        return new Packet(PacketEnum.ERROR, "Invalid username or password");
    }

    public static void main(String[] args) {
        Server server = new Server();
        server.openServer();
    }
}
