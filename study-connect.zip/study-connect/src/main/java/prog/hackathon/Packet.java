package prog.hackathon;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.io.ObjectInputStream;
import java.io.ByteArrayInputStream;

public class Packet implements Serializable {
    public PacketEnum type;
    public Object[] data;

    public enum PacketEnum {
        LOGIN,
        DECLARE_INFO,
        SIGN_UP,
        ERROR,
        SUCCESS,
        RESPONSE,
        LINK
    }

    public Packet(PacketEnum type, Object... data) {
        this.type = type;
        this.data = data;
    }

    public byte[] serialize() {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try (ObjectOutputStream out = new ObjectOutputStream(bos)) {
            out.writeObject(this);
            out.flush();
            return bos.toByteArray();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public static Packet deserialize(byte[] data) {
        try {
            return (Packet) (new ObjectInputStream(new ByteArrayInputStream(data)).readObject());
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public String toString() {
        return "Packet{" +
                "type=" + type +
                ", data=" + Arrays.toString(data) +
                '}';
    }

}
