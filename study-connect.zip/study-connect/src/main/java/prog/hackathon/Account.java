
package prog.hackathon;

import com.fasterxml.jackson.annotation.JsonProperty;



public class Account {
    @JsonProperty("username")
    private String username;

    @JsonProperty("password")
    private String password;

    @JsonProperty("grade")
    private int grade;

    // Default constructor
    public Account() {
    }

    public Account(String username, String password, int grade) {
        this.username = username;
        this.password = password;
        this.grade = grade;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getGrade() {
        return grade;
    }

    public String toString() {
        return "Username: " + username + ", Password: " + password + ", Grade: " + grade;
    }
}
