package prog.hackathon;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class FindTime {
    final int MIN_LIMIT = 30;
    public StudyGroup findTime(ArrayList<Users.User> list) {

        Calendar lowestDate = Calendar.getInstance();
        Calendar highestDate = Calendar.getInstance();
        lowestDate.set(Calendar.HOUR, Integer.MAX_VALUE);
        highestDate.set(Calendar.HOUR, Integer.MIN_VALUE);
        lowestDate.set(Calendar.SECOND, 0);
        highestDate.set(Calendar.SECOND, 0);

        for(Users.User user : list) {
           ArrayList<Schedule.TimeSlot> timeSlots = user.schedule.timeSlots;
              for(Schedule.TimeSlot timeSlot : timeSlots) {
                if(timeSlot.startTimeSlot.compareTo(lowestDate) < 0) {
                     lowestDate = timeSlot.startTimeSlot;
                }
                if(timeSlot.endTimeSlot.compareTo(highestDate) > 0) {
                    highestDate = timeSlot.endTimeSlot;
                }
              }
        }

        //System.out.println("Lowest Date: " + lowestDate.getTime());
        //System.out.println("Highest Date: " + highestDate.getTime());
        lowestDate = new Calendar.Builder().setInstant(lowestDate.getTime().getTime()).build();
        highestDate = new Calendar.Builder().setInstant(highestDate.getTime().getTime()).build();
        double maxRatio = -1000;
        ArrayList <Users.User> group = new ArrayList<>();
        StudyGroup sg = null;
        while (lowestDate.compareTo(highestDate) < 0){
            int counter = 0;
            for(Users.User user : list) {
                ArrayList<Schedule.TimeSlot> timeSlots = user.schedule.timeSlots;
                for(Schedule.TimeSlot timeSlot : timeSlots) {
                    if((lowestDate.getTime().getTime() + (60 * 60 * 1000))  >= timeSlot.startTimeSlot.getTime().getTime() && lowestDate.getTime().getTime() <= timeSlot.endTimeSlot.getTime().getTime() - (MIN_LIMIT * 60 * 1000)) {
                        counter++;
                        group.add(user);
                        break;
                    }
                }
                if (lowestDate.get(Calendar.HOUR_OF_DAY) == 11 && lowestDate.get(Calendar.MINUTE) == 30) {
                    //System.out.println("Counter: " + counter);
                    //System.out.println(user.schedule.timeSlots.size());
                }
            }
            // print out counter when time is 11:30
            
            if(counter > 1) {
                double ratio = (double)counter/list.size();
                if(ratio > maxRatio){
                    //System.out.println("Ratio: " + ratio + " Date: " + lowestDate.getTime());
                    maxRatio = ratio;
                    sg = new StudyGroup(new Calendar.Builder().setInstant(lowestDate.getTime().getTime()).build(), list.get(0).subject, group.toArray(new Users.User[0]));
                    //System.out.println("Group Size: " + lowestDate.getTime());
                }
            }
            group.clear();
            counter = 0;
            lowestDate.set(Calendar.MINUTE,lowestDate.get(Calendar.MINUTE) + 1);
        }
        System.out.println("Max Ratio: " + maxRatio);
        return sg;
    }

    public static void main(String[] args) {
        //FindTime findTime = new FindTime();
        Users users = new Users();
        /*Date date = new Date();
        date.setHours(10);
        date.setMinutes(0);
        date = (new Calendar.Builder().setInstant(date).build()).getTime();
        Date date2 = new Date();
        date2.setHours(12);
        date2.setMinutes(0);
        date2 = (new Calendar.Builder().setInstant(date2).build()).getTime();
        Date date3 = new Date();
        date3.setHours(11);
        date3.setMinutes(0);
        date3.setSeconds(0);
        date3 = (new Calendar.Builder().setInstant(date3).build()).getTime();
        Date date4 = new Date();
        date4.setHours(16);
        date4.setMinutes(0);
        date4.setSeconds(0);
        date4 = (new Calendar.Builder().setInstant(date4).build()).getTime();
        Schedule schedule = new Schedule();
        schedule.addTimeSlot(date, date2);
        Schedule schedule2 = new Schedule();
        schedule2.addTimeSlot(date3, date4);
        users.addUser(new Account("Hello", "hi", 1), null);
        users.addUser(new Account("Hello", "hi", 1), null);
        users.getUsers().get(0).schedule = schedule;
        users.getUsers().get(1).schedule = schedule2;
        Date date5 = new Date();
        date5.setHours(11);
        date5.setMinutes(55);
        date5.setSeconds(0);
        date5 = (new Calendar.Builder().setInstant(date5).build()).getTime();
        Date date6 = new Date();
        date6.setHours(18);
        date6.setMinutes(35);
        date6.setSeconds(0);
        date6 = (new Calendar.Builder().setInstant(date6).build()).getTime();*/
        Calendar calendar1 = Calendar.getInstance();
        calendar1.set(Calendar.HOUR_OF_DAY, 10);
        calendar1.set(Calendar.MINUTE, 0);
        calendar1.set(Calendar.SECOND, 0);
        calendar1 = GMT(calendar1);
        Calendar calendar2 = Calendar.getInstance();
        calendar2.set(Calendar.HOUR_OF_DAY, 12);
        calendar2.set(Calendar.MINUTE, 0);
        calendar2.set(Calendar.SECOND, 0);
        calendar2 = GMT(calendar2);
        Schedule schedule1 = new Schedule();
        schedule1.addTimeSlot(calendar1.getTime(), calendar2.getTime());
        users.addUser(new Account("Hello", "hi", 1), null);
        users.getUsers().get(0).schedule = schedule1;
        users.getUsers().get(0).subject = "CS";
        Calendar calendar3 = Calendar.getInstance();
        calendar3.set(Calendar.HOUR_OF_DAY, 11);
        calendar3.set(Calendar.MINUTE, 0);
        calendar3.set(Calendar.SECOND, 0);
        calendar3 = GMT(calendar3);
        Calendar calendar4 = Calendar.getInstance();
        calendar4.set(Calendar.HOUR_OF_DAY, 16);
        calendar4.set(Calendar.MINUTE, 0);
        calendar4.set(Calendar.SECOND, 0);
        calendar4 = GMT(calendar4);
        Schedule schedule2 = new Schedule();
        schedule2.addTimeSlot(calendar3.getTime(), calendar4.getTime());
        users.addUser(new Account("Hello", "hi", 1), null);
        users.getUsers().get(1).schedule = schedule2;
        users.getUsers().get(1).subject = "CS";

        Calendar calendar5 = Calendar.getInstance();
        calendar5.set(Calendar.HOUR_OF_DAY, 11);
        calendar5.set(Calendar.MINUTE, 55);
        calendar5.set(Calendar.SECOND, 0);
        calendar5 = GMT(calendar5);
        Calendar calendar6 = Calendar.getInstance();
        calendar6.set(Calendar.HOUR_OF_DAY, 18);
        calendar6.set(Calendar.MINUTE, 0);
        calendar6.set(Calendar.SECOND, 0);
        calendar6 = GMT(calendar6);
        Schedule schedule3 = new Schedule();
        schedule3.addTimeSlot(calendar5.getTime(), calendar6.getTime());
        users.addUser(new Account("Hello", "hi", 1), null);
        users.getUsers().get(2).schedule = schedule3;
        users.getUsers().get(2).subject = "CS";

        Calendar calendar7 = Calendar.getInstance();
        calendar7.set(Calendar.HOUR_OF_DAY, 1);
        calendar7.set(Calendar.MINUTE, 0);
        calendar7.set(Calendar.SECOND, 0);
        calendar7 = GMT(calendar7);
        Calendar calendar8 = Calendar.getInstance();
        calendar8.set(Calendar.HOUR_OF_DAY, 4);
        calendar8.set(Calendar.MINUTE, 0);
        calendar8.set(Calendar.SECOND, 0);
        calendar8 = GMT(calendar8);
        Calendar calendar9 = Calendar.getInstance();
        calendar9.set(Calendar.HOUR_OF_DAY, 1);
        calendar9.set(Calendar.MINUTE, 0);
        calendar9.set(Calendar.SECOND, 0);
        calendar9 = GMT(calendar9);
        Calendar calendar10 = Calendar.getInstance();
        calendar10.set(Calendar.HOUR_OF_DAY, 4);
        calendar10.set(Calendar.MINUTE, 0);
        calendar10.set(Calendar.SECOND, 0);
        calendar10 = GMT(calendar10);
        Schedule schedule4 = new Schedule();
        schedule4.addTimeSlot(calendar7.getTime(), calendar8.getTime());
        Schedule schedule5 = new Schedule();
        schedule5.addTimeSlot(calendar9.getTime(), calendar10.getTime());
        users.addUser(new Account("Hello", "hi", 1), null);
        users.addUser(new Account("Hello", "hi", 1), null);
        users.getUsers().get(3).schedule = schedule4;
        users.getUsers().get(4).schedule = schedule5;
        users.getUsers().get(3).subject = "Math";
        users.getUsers().get(4).subject = "Math";
        
        //System.out.println(calendar7.getTime() + " " + calendar8.getTime());
        //System.out.println(calendar9.getTime() + " " + calendar10.getTime());
        //System.out.println(date5.getTime() - (30 * 60 * 1000));
        new FindTime().fetchGroups(users);
        //findTime.findTime(users);
    }
    public ArrayList <StudyGroup> fetchGroups(Users users) {
        ArrayList<StudyGroup> allGroups = new ArrayList<>();
        while(users.getUsers().size() > 0) {
            String s = users.getUsers().get(0).subject;
            ArrayList<Users.User> temp = new ArrayList<>();
            for(int i = 0; i < users.getUsers().size(); i++) {
                if(users.getUsers().get(i).subject.equalsIgnoreCase(s)) {
                    temp.add(users.getUsers().get(i));
                    users.getUsers().remove(i);
                    i--;
                }
            }
            ArrayList<StudyGroup> all = FindTimes(temp);
            for (StudyGroup group : all) {
                allGroups.add(group);
            }
        }
        return allGroups;
    }

    public ArrayList<StudyGroup> FindTimes(ArrayList<Users.User> users) {
        ArrayList<StudyGroup> allGroups = new ArrayList<>();
        StudyGroup newGroups = findTime(users);
        
        while (newGroups != null && users.size() > 1){
            allGroups.add(newGroups);
            for (Users.User user : newGroups.participants) {
                //System.out.println(user.schedule.timeSlots.get(0).startTimeSlot.getTime());
                users.remove(user);
            }
            //System.out.println(users.size() + "i" + newGroups);

            newGroups = findTime(users);
            for(Users.User user : users) {
                //System.out.println(user.schedule.timeSlots.get(0).startTimeSlot.getTime());
            }
        }
        for (StudyGroup group : allGroups) {
            System.out.println(group.date.getTime() + " " + group.participants.length + "subject" + group.subject);
        }
        return allGroups;
    }

    private static Calendar GMT( Calendar c ){
        Date date = c.getTime();
        TimeZone tz = TimeZone.getDefault();
        Date ret = new Date( date.getTime() - tz.getRawOffset() );

        // if we are now in DST, back off by the delta.  Note that we are checking the GMT date, this is the KEY.
        if ( tz.inDaylightTime( ret )){
            Date dstDate = new Date( ret.getTime() - tz.getDSTSavings() );

            // check to make sure we have not crossed back into standard time
            // this happens when we are on the cusp of DST (7pm the day before the change for PDT)
            if ( tz.inDaylightTime( dstDate )){
                ret = dstDate;
            }
        }
        return new Calendar.Builder().setInstant(ret).build();
    }

    class StudyGroup {
        Calendar date;
        String subject;
        Users.User[] participants;
        
        public StudyGroup(Calendar date, String subject, Users.User[] participants) {
            this.date = date;
            this.subject = subject;
            this.participants = participants;
        }

        public String toString() {
            return date.getTime() + " " + subject + " " + participants.length;
        }
    }
}
