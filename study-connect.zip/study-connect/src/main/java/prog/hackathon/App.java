package prog.hackathon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusListener;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Date;

import javax.swing.border.EmptyBorder;

import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;

import raven.datetime.component.date.DatePicker;




public class App implements ActionListener {

    JButton proceedButton;
    CardLayout c;
    JPanel card;
    Client client;
    PTextField username;
    PTextField password;
    JLabel emptyLabel;
    PTextField grade;
    JPanel textFields;
    JLabel error;
    JTextArea schedule;
    Schedule s;
    JTextArea textArea;
    JTextArea waitingLabel;

    public static void main(String[] args) {
        new App();
    }

    public App() {

        s = new Schedule();

        client = new Client();
        client.startConnection("10.20.88.89", 17047);
        client.startListening();

        JFrame frame = new JFrame("Study Connect");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        c = new CardLayout();

        card = new JPanel(c);

        JButton loginButton = new JButton("Log In");
        JButton signUpButton = new JButton("Sign Up");

        // Increase font size of buttons
        Font buttonFont = new Font(loginButton.getFont().getName(), Font.PLAIN, 18);
        loginButton.setFont(buttonFont);
        loginButton.addActionListener(this);
        signUpButton.setFont(buttonFont);
        signUpButton.addActionListener(this);

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(loginButton);
        bottomPanel.add(signUpButton);

        JPanel all = new JPanel(new BorderLayout());
        all.add(bottomPanel, BorderLayout.SOUTH);
        JLabel label = new JLabel("Welcome to Study Connect");

        // Increase font size of label
        Font labelFont = new Font(label.getFont().getName(), Font.BOLD, 25);
        label.setFont(labelFont);

        label.setHorizontalAlignment(SwingConstants.CENTER);
        all.add(label, BorderLayout.CENTER);

        card.add(all, "Welcome");

        JPanel credentials = new JPanel();
        credentials.setLayout(new BorderLayout());
        textFields = new JPanel(new GridLayout(5, 1));
        username = new PTextField("Username");
        username.setHorizontalAlignment(JTextField.CENTER);
        password = new PTextField("Password");
        password.setHorizontalAlignment(JTextField.CENTER);
        JLabel prompt = new JLabel("Enter your credentials");
        prompt.setHorizontalAlignment(SwingConstants.CENTER);
        error = new JLabel();
        error.setHorizontalAlignment(SwingConstants.CENTER);
        error.setForeground(Color.RED);
        emptyLabel = new JLabel();
        grade = new PTextField("Grade");
        grade.setHorizontalAlignment(JTextField.CENTER);
        Font promptFont = new Font(prompt.getFont().getName(), Font.BOLD, 18);
        prompt.setFont(promptFont);
        textFields.add(emptyLabel);
        textFields.add(prompt);
        textFields.add(username);
        textFields.add(password);
        textFields.add(error);
        textFields.setBorder(BorderFactory.createEmptyBorder(0, 100, 10, 100));
        credentials.add(textFields, BorderLayout.CENTER);
        JPanel bottom = new JPanel();
        proceedButton = new JButton("");
        proceedButton.addActionListener(this);
        JButton backButton = new JButton("Back");
        backButton.addActionListener(this);
        bottom.add(proceedButton);
        bottom.add(backButton);
        credentials.add(bottom, BorderLayout.SOUTH);

        card.add(credentials, "Credentials");

        // The next panel is the home page, with a big text area on the left where the user to type, a submit button on the bottom, and another uneditaable text area on the right. The text area on the left has a label above it saying "describe what you will be studying in detail". The one on the right has a label above it that says "your schedule". It also has a button below it called add timeslot
        JPanel home = new JPanel();
        home.setLayout(new BorderLayout());
        JPanel left = new JPanel();
        left.setBorder(new EmptyBorder(10, 10, 10, 10));
        left.setLayout(new BorderLayout());
        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        JLabel textAreaLabel = new JLabel("Describe what you will be studying in detail");
        Font textAreaFont = new Font(textAreaLabel.getFont().getName(), Font.BOLD, 18);
        textAreaLabel.setFont(textAreaFont);
        textAreaLabel.setHorizontalAlignment(SwingConstants.CENTER);
        left.add(textAreaLabel, BorderLayout.NORTH);
        left.add(scrollPane, BorderLayout.CENTER);
        home.add(left, BorderLayout.WEST);
        JPanel right = new JPanel();
        right.setLayout(new BorderLayout());
        schedule = new JTextArea();
        schedule.setEditable(false);
        JScrollPane scheduleScrollPane = new JScrollPane(schedule);
        JLabel scheduleLabel = new JLabel("Your schedule");
        Font scheduleFont = new Font(scheduleLabel.getFont().getName(), Font.BOLD, 18);
        scheduleLabel.setFont(scheduleFont);
        scheduleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        right.add(scheduleLabel, BorderLayout.NORTH);
        right.add(scheduleScrollPane, BorderLayout.CENTER);
        JPanel timeSlotButtons = new JPanel();
        JButton addTimeSlot = new JButton("Add Time Slot");
        addTimeSlot.addActionListener(this);
        timeSlotButtons.add(addTimeSlot);
        JButton removeTimeSlot = new JButton("Remove Time Slot");
        removeTimeSlot.addActionListener(this);
        timeSlotButtons.add(removeTimeSlot);
        right.add(timeSlotButtons, BorderLayout.SOUTH);
        right.setBorder(new EmptyBorder(10, 10, 10, 10));
        home.add(right, BorderLayout.CENTER);
        JPanel under = new JPanel();
        JButton submit = new JButton("Submit");
        submit.addActionListener(this);
        under.add(submit);
        home.add(under, BorderLayout.SOUTH);
        card.add(home, "Home");
        
        JPanel waiting = new JPanel();
        // shows a big JLabel on the screen saying waiting...
        waitingLabel = new JTextArea("Waiting...");
        waitingLabel.setEditable(false);
        waitingLabel.setFont(new Font(waitingLabel.getFont().getName(), Font.PLAIN, 12));
        waitingLabel.setAlignmentX(SwingConstants.CENTER);
        waitingLabel.setAlignmentY(SwingConstants.CENTER);
        waiting.add(waitingLabel);
        card.add(waiting, "Waiting");


        frame.add(card);
        frame.setSize(800, 575);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Back")) {
                c.previous(card);
            } else if (button.getText().equals("Add Time Slot")) {
                FlatLaf.registerCustomDefaultsSource("themes");
                FlatMacDarkLaf.setup();
                s.addTimeSlot(new Date(), new Date());
                schedule.append("\n");
                TestDate date = new TestDate(s, schedule);
                date.setVisible(true);
                
            } else if (button.getText().equals("Remove Time Slot")) {
                s.removeTimeSlot(s.timeSlots.size() - 1);
                // remove last line of schedule text area
                String[] lines = schedule.getText().split("\n");
                String newText = "";
                for (int i = 0; i < lines.length - 1; i++) {
                    newText += lines[i] + "\n";
                }
                schedule.setText(newText);
            } else if (button.getText().equals("Submit")) {
                Packet p = new Packet(Packet.PacketEnum.DECLARE_INFO, textArea.getText(), s);
                try {
                    Packet received = client.sendPacket(p);
                    System.out.println(received.data[0]);
                    c.show(card, "Waiting");
                    Thread t = new Thread(new Runnable() {
                        public void run() {
                            while (client.responsePackets.size() == 0) {
                                System.out.print("");
                            }
                            Packet response = client.responsePackets.get(0);
                            client.responsePackets.remove(0);
                            String link = (String) response.data[0];
                            System.out.println(link);
                            waitingLabel.setText(link);
                        }
                    });
                    t.start();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            else if (button == proceedButton) {
                if (username.getText().equals("") || password.getText().equals("")) {
                    return;
                }
                if (username.getForeground() == Color.GRAY || password.getForeground() == Color.GRAY) {
                    return;
                }
                Packet p = null;
                if (proceedButton.getText().equals("Log In")) {
                    p = client.login(username.getText(), password.getText());
                    if (p.type == Packet.PacketEnum.ERROR) {
                        error.setText((String)p.data[0]);
                        return;
                    }
                    c.show(card, "Home");
                } else {
                    try {
                        p = client.registerAccount(username.getText(), password.getText(), Integer.parseInt(grade.getText()));
                    } catch (NumberFormatException ex) {
                        error.setText("Grade must be a number");
                        return;
                    }
                    if (p.type == Packet.PacketEnum.ERROR) {
                        error.setText((String)p.data[0]);
                        return;
                    }
                    c.show(card, "Welcome");
                }
                
                
            } else if (button.getText().equals("Log In")) {
                proceedButton.setText("Log In");
                if (grade.getParent() == textFields) {
                    textFields.remove(grade);
                    textFields.remove(error);
                    textFields.add(emptyLabel, 1);
                    textFields.add(error);
                }
                c.next(card);
            } else if (button.getText().equals("Sign Up")) {
                proceedButton.setText("Sign Up");
                textFields.remove(emptyLabel);
                textFields.remove(error);
                textFields.add(grade);
                textFields.add(error);
                c.next(card);
            } 
            error.setText("");
            // set all text to nothing
            if (username.getForeground() != Color.GRAY) {
                username.setText("Username");
                username.setForeground(Color.GRAY);
            }
            if (password.getForeground() != Color.GRAY) {
                password.setText("Password");
                password.setForeground(Color.GRAY);
            }
            if (grade.getForeground() != Color.GRAY) {
                grade.setText("Grade Level");
                grade.setForeground(Color.GRAY);
            }
        }
    }
}