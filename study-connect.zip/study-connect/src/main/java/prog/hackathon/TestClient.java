
package prog.hackathon;
import java.net.Socket;
import java.io.IOException;



public class TestClient {
    public static void main(String[] args) {
        String ipAddress = "10.20.88.89";
        int port = 17047;

        try {
            Socket socket = new Socket(ipAddress, port);
            // Connection successful, do something with the socket
            System.out.println("Connected to " + ipAddress + " on port " + port);
            // ...
            socket.close();
        } catch (IOException e) {
            // Connection failed, handle the exception
            System.out.println("Failed to connect to " + ipAddress + " on port " + port);
            e.printStackTrace();
        }
    }
}
