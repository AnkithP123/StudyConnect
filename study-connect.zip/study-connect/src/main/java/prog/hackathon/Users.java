package prog.hackathon;

import java.net.Socket;
import java.util.ArrayList;

public class Users {
    
    private ArrayList<User> users = new ArrayList<>();

    public void addUser(Account acc, Socket sock) {
        users.add(new User(acc, sock));
        System.out.println("User registered: " + acc.getUsername());
    }

    public void removeUser(Account acc) {
        for (User user : users) {
            if (user.account.equals(acc)) {
                users.remove(user);
                break;
            }
        }
    }

    public User getUser(Account acc) {
        for (User user : users) {
            if (user.account.equals(acc)) {
                return user;
            }
        }
        return null;
    }

    public User getUser(Socket sock) {
        for (User user : users) {
            if (user.socket.equals(sock)) {
                return user;
            }
        }
        return null;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    class User {
        Account account;
        Socket socket;
        String subject;
        String higherLevel;
        Schedule schedule;

        public User(Account acc, Socket sock) {
            account = acc;
            socket = sock;
        }
    }
}
