package prog.hackathon;
import java.net.*;
import java.util.Base64;
import java.util.Calendar;

import prog.hackathon.Packet.PacketEnum;

import java.io.*;
import java.util.Date;
import java.util.TimeZone;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class Client {

    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    ArrayList<Packet> responsePackets = new ArrayList<Packet>();

    public void startConnection(String ip, int port){
        try{
            clientSocket = new Socket(ip, port);
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void startListening() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Listening for server response");
                while(true) {
                    try {
                        if (in.ready()) {
                            String response = in.readLine();
                            byte[] decoded = Base64.getDecoder().decode(response);
                            Packet responsePacket = Packet.deserialize(decoded);
                            //System.out.println(responsePacket);
                            if (responsePacket != null) {
                                responsePackets.add(responsePacket);
                                System.out.println(responsePacket.type);
                                System.out.println(responsePacket.data[0]);
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        t.start();
    }

    public Packet sendPacket(Packet packet) throws IOException {
        // send packet to server
        System.out.println("Sending packet to server");
        byte[] data = packet.serialize();
        Base64.Encoder encoder = Base64.getEncoder();
        String encoded = encoder.encodeToString(data);
        out.println(encoded);

        // wait until response
        Packet response = null;
        while (responsePackets.size() ==  0) {
            System.out.print("");
        }     
        response = responsePackets.get(0);
        responsePackets.remove(0);
        System.out.println("Received response from server");
        return response;
    }
    
    public Packet registerAccount(String username, String password, int grade) {
        Packet packet = new Packet(Packet.PacketEnum.SIGN_UP, username, password, grade);

        // send packet to server
        Packet response  = null;
        try {
            response = sendPacket(packet);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;

    }

    public Packet login(String username, String password) {
        Packet packet = new Packet(Packet.PacketEnum.LOGIN, username, password);

        // send packet to server
        Packet response  = null;
        try {
            System.out.println("in try");
            response = sendPacket(packet);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;

    }

    private static Calendar GMT( Calendar c ){
        Date date = c.getTime();
        TimeZone tz = TimeZone.getDefault();
        Date ret = new Date( date.getTime() - tz.getRawOffset() );

        // if we are now in DST, back off by the delta.  Note that we are checking the GMT date, this is the KEY.
        if ( tz.inDaylightTime( ret )){
            Date dstDate = new Date( ret.getTime() - tz.getDSTSavings() );

            // check to make sure we have not crossed back into standard time
            // this happens when we are on the cusp of DST (7pm the day before the change for PDT)
            if ( tz.inDaylightTime( dstDate )){
                ret = dstDate;
            }
        }
        return new Calendar.Builder().setInstant(ret).build();
    }


    public static void main(String[] args) {
        new Client();
    }

    public Client(){
 
        
    }

    

}
