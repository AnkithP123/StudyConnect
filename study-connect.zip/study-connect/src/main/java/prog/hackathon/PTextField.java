package prog.hackathon;

import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class PTextField extends JTextField {

    private boolean typed;

    public PTextField(final String promptText) {
        super(promptText);
        typed = false;
        setForeground(Color.GRAY);
        addFocusListener(new FocusListener() {

            @Override
            public void focusLost(FocusEvent e) {
                if(getText().isEmpty()) {
                    setText(promptText);
                    setForeground(Color.GRAY);
                }
            }

            @Override
            public void focusGained(FocusEvent e) {
                if(getText().equals(promptText) && getForeground() == Color.GRAY) {
                    setText("");
                    setForeground(Color.BLACK);
                }
            }
        });


    }

}