package prog.hackathon;

import java.util.Calendar;
import java.util.Date;
import java.io.Serializable;
import java.util.ArrayList;

public class Schedule implements Serializable {
    ArrayList<TimeSlot> timeSlots;

    public Schedule(){
        timeSlots = new ArrayList<TimeSlot>();
    }

    public void addTimeSlot(Date startTime, Date endTime){
        timeSlots.add(new TimeSlot(startTime, endTime));
    }

    public void removeTimeSlot(int index){
        timeSlots.remove(index);
    }

    public class TimeSlot implements Serializable {
        Calendar startTimeSlot;
        Calendar endTimeSlot;

        public TimeSlot(Date startTime, Date endTime){
            startTimeSlot =  new Calendar.Builder().setInstant(startTime).build();
            endTimeSlot = new Calendar.Builder().setInstant(endTime).build();
        }
    }
}