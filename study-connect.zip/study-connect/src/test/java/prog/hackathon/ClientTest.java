package prog.hackathon;
import org.junit.jupiter.api.Test;

import prog.hackathon.Packet.PacketEnum;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;

class ClientTest {
    @Test
    void testSendPacketWithSignupPacket() throws IOException {
        // Create a mock packet for signup
        Packet signupPacket = new Packet(PacketEnum.SIGN_UP, "username", "password", 1);
        // Set the necessary data for signup packet
        // ...

        // Create a mock server
        Server mockServer = new Server();

        // Create a mock input/output streams
        // ...

        // Create a mock client
        Client client = new Client();
        client.startConnection("10.20.80.89", 17047);

        // Call the sendPacket method with the signup packet
        Packet response = client.sendPacket(signupPacket);

        // Assert the response is not null
        assertNotNull(response);

        // Assert the response is as expected
        // ...
    }
}